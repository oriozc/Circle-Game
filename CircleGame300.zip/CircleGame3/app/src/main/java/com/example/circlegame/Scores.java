package com.example.circlegame;

import java.util.ArrayList;

public class Scores {
    private ArrayList<Score> scores = new ArrayList<>();
    private static Scores instance = null;

    private Scores() {
    }

    public ArrayList<Score> getScores() {
        return scores;
    }

    public void addScore(int eatenEnemies){
        scores.add(new Score(eatenEnemies));
    }

    static Scores setInstance(){
        if (instance == null)
            instance = new Scores();

        return instance;
    }
}