package com.example.circlegame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Display;

public class MainActivity extends AppCompatActivity {

    //declaring gameview
    private GameView gameView;
    GameHandler handler = new GameHandler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gameView = new GameView(this, handler);

        //adding it to contentview
        setContentView(gameView);
    }

    //pausing the game when activity is paused
    @Override
    protected void onPause() {
        super.onPause();
        gameView.pause();
    }

    // running the game when activity is resumed
    @Override
    protected void onResume() {
        super.onResume();
        gameView.resume();
    }


    class GameHandler extends Handler{

        @Override
        public void handleMessage(Message msg) {  gameView.pause();

            Intent intent = new Intent(getApplicationContext(), EndGame.class);
            startActivity(intent);
        }
    }

}