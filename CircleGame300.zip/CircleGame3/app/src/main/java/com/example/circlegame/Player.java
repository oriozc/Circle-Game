package com.example.circlegame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

public class Player {
    //Bitmap to get character from image
    private Bitmap bitmap;

    //coordinates
    private int x;
    private int y;

    //motion speed of the character
    private int speed = 0;


    private int maxY;
    private int minY;


    private final double SPEED_PIXELS_PER_SECOND = 400.0;
    private final double MAX_SPEED = SPEED_PIXELS_PER_SECOND / 30.0;
    private double velocityX;
    private double velocityY;


    private Rect detectCollision;

    private int dstWidth = 120;
    private int dstHeight = 120;

    //constructor
    public Player(Context context) {
        x = 950;
        y = 400;
        speed = 1;

        //Getting bitmap from drawable resource
        bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.player);

        bitmap = Bitmap.createScaledBitmap(bitmap, dstWidth, dstHeight, false);

        //initializing rect object
        detectCollision =  new Rect(x, y, bitmap.getWidth(), bitmap.getHeight());
    }


    public void update(Joystick joystick, int eatenEnemies){
        // change his size
        bitmap = Bitmap.createScaledBitmap(bitmap, dstWidth + (eatenEnemies*10), dstHeight+ (eatenEnemies*10), false);


        //update coordinate of character
        velocityX = joystick.getActuatorX()*MAX_SPEED;
        velocityY = joystick.getActuatorY()*MAX_SPEED;
        x += velocityX;
        y += velocityY;


        //adding top, left, bottom and right to the rect object
        detectCollision.left = x;
        detectCollision.top = y;
        detectCollision.right = x + bitmap.getWidth();
        detectCollision.bottom = y + bitmap.getHeight();
    }

    //one more getter for getting the rect object
    public Rect getDetectCollision() {
        return detectCollision;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getSpeed() {
        return speed;
    }

    public void SetX(int x){
        this.x = x;
    }

    public void SetY(int y){
        this.y = y;
    }

}
