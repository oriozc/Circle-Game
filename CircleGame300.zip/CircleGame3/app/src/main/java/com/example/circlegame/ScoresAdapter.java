package com.example.circlegame;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ScoresAdapter extends RecyclerView.Adapter<ScoresAdapter.ScoresViewHolder> {

    private ArrayList<Score> scores;

    public ScoresAdapter(ArrayList<Score> scores) {
        this.scores = scores;
    }

    @NonNull
    @Override
    public ScoresViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View scoresView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycleritem_scores, parent, false);
        return new ScoresViewHolder(scoresView);
    }

    @Override
    public void onBindViewHolder(@NonNull ScoresViewHolder holder, int position) {
        Score currentScore = scores.get(position);
        holder.scoreTextView.setText(currentScore.getScore()+"");
    }

    @Override
    public int getItemCount() {
        return scores.size();
    }

    public static class ScoresViewHolder extends RecyclerView.ViewHolder {
        public TextView scoreTextView;

        public ScoresViewHolder(@NonNull View itemView) {
            super(itemView);
            scoreTextView = itemView.findViewById(R.id.textview_score);
        }
    }
}
