package com.example.circlegame;

import static android.graphics.Color.rgb;


import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;


public class GameView extends SurfaceView implements Runnable {

    private final Joystick joystick;
    volatile boolean playing;
    private Thread gameThread = null;

    //adding the player to this class
    private Player player;

    //These objects will be used for drawing
    private Paint paint;
    private Canvas canvas;
    private SurfaceHolder surfaceHolder;


    //Adding enemies object array
    private Enemy[] enemies;

    //Adding 3 enemies
    private int enemyCount = 3;

    private int eatenEnemies;


    //Adding bombs object array
    private Bomb[] bombs;

    // Adding 1 bomb
    private int bombCount = 1;


    private MainActivity.GameHandler handler;


    public GameView(Context context, MainActivity.GameHandler h) {
        super(context);

        joystick = new Joystick(250, 570, 70 ,40);

        //initializing player object
        player = new Player(context);

        //initializing drawing objects
        surfaceHolder = getHolder();
        paint = new Paint();

        enemies = new Enemy[enemyCount];
        for(int i=0; i<enemyCount; i++){
            enemies[i] = new Enemy(context, 1000, 1000);
        }

        eatenEnemies = 0;

        bombs = new Bomb[bombCount];
        for (int i=0; i<bombCount; i++){
            bombs[i] = new Bomb(context, 1000, 1000);
        }

        handler = h;
    }


    @Override
    public void run() {
        while (playing) {
            update();
            draw();
            control();
        }
    }


    public void update() {
        joystick.update();

        player.update(joystick, eatenEnemies);



        bombs[0].update();

        //if player touch a bomb
        if (Rect.intersects(player.getDetectCollision(), bombs[0].getDetectCollision())) {
            Scores.setInstance().addScore(eatenEnemies);

            // move into EndGame activity
            handler.sendMessage(handler.obtainMessage());
        }


        for(int i=0; i<enemyCount; i++){
            enemies[i].update();

            //if collision occurs with player
            if (Rect.intersects(player.getDetectCollision(), enemies[i].getDetectCollision())) {
                //moving enemy outside the left edge:
                enemies[i].setX(-500);
                enemies[i].setY(-500);

                eatenEnemies++;

                // to make the player bigger:
                player.update(joystick, eatenEnemies);
            }
        }
    }

    public void draw() {
        //checking if surface is valid
        if (surfaceHolder.getSurface().isValid()) {
            //locking the canvas
            canvas = surfaceHolder.lockCanvas();
            //drawing a background color for canvas
            canvas.drawColor(Color.BLACK);

            joystick.draw(canvas);

            //drawing the enemies
            for (int i = 0; i < enemyCount; i++) {
                canvas.drawBitmap(
                        enemies[i].getBitmap(),
                        enemies[i].getX(),
                        enemies[i].getY(),
                        paint
                );
            }

            //drawing the bombs
            for (int i = 0; i < bombCount; i++) {
                canvas.drawBitmap(
                        bombs[i].getBitmap(),
                        bombs[i].getX(),
                        bombs[i].getY(),
                        paint
                );
            }

            //Drawing the player
            canvas.drawBitmap(
                    player.getBitmap(),
                    player.getX(),
                    player.getY(),
                    paint);
            //Unlocking the canvas
            surfaceHolder.unlockCanvasAndPost(canvas);
        }
    }

    public void control() {
        try {
            gameThread.sleep(17);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void pause() {
        playing = false;
        try {
            gameThread.join();
        }
        catch (InterruptedException e) {
        }
    }

    public void resume() {
        playing = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent){
        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK){
            case MotionEvent.ACTION_DOWN:
                if (joystick.isPressed((double) motionEvent.getX(), (double) motionEvent.getY() )){
                    joystick.setIsPressed(true);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (joystick.getIsPressed()){
                    joystick.setActuator((double) motionEvent.getX(), (double) motionEvent.getY());
                }
                return true;
            case MotionEvent.ACTION_UP:
                joystick.setIsPressed(false);
                joystick.resetActuator();
                return true;
        }
        return true;
    }
}